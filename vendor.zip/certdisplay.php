<?php

?>
<html>
    <head> 
        <title> CertDisplay </title>
</head>
<body>

<h1> Fill Your Roll Nu Below </h1>

<form action="certdisplayproces.php" method="post">
    <table>
        <tr>
            <tr>
                <td> Roll Nu: </td>
                <td> <input type="number" name="rln" required> </td>
</tr>
</tr>
</table>
                        <input type="submit" value="Show" />
                        <input type="reset" value=" Clear" />


</body>
    </html>