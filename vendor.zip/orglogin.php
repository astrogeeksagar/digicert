<html>

<head>
    <title>Login</title>
</head>

<body>

    <h1> Login </h1>
    <br />
    <div class="login">
        <span>
        <center>
            <h3>Fill Your Login Details Below</h3>
            <form action="Login.php" method="post">
                <table>
                    <tr>
                    <tr>
                        <td>
                            <p>Office Mobile:</p>
                        </td>
                        <td> <input type="number" name="mob" required /> </td>
                    </tr>
                    <tr>
                        <td>
                            <p>Password:</p>
                        </td>
                        <td> <input type="password" name="opwd" required /> </td>
                    </tr>
                </table>
                <br />
                <td>
                    <input type="submit" value="Login" />
                    <input type="reset" value=" Clear" />
                </td>
        </center>
    </span>
    </div>
    <br />

</body>

</html>