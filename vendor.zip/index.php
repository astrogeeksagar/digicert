<?php
include("header.php");
include("includefiles.html");

?>
<html>

<head>
    <title>Digital Certificate Generation System</title>
</head>

<body>

   <!-- ***** Preloader Start ***** -->
   <div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div>
  <!-- ***** Preloader End ***** -->
  
      

        <br/>
        <br/>
        <br/>
        <br/>
        <br/>

        <div class="nav-bar">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="#">Solution</a></li>
                <li><a href="#">Pricing</a></li>
                <li><a href="#">Show Demo</a></li>
                <li><a href="#">Contact</a></li>
                <li><a href="orgreg.html">Register</a></li>
                <li><a href="orglogin.php">Login</a></li>
            </ul>
        </div>
        

    <div class="slidershow middle">

        <div class="slides">
          <input type="radio" name="r" id="r1" checked>
          <input type="radio" name="r" id="r2">
          <input type="radio" name="r" id="r3">
          <input type="radio" name="r" id="r4">
          <input type="radio" name="r" id="r5">
          <div class="slide s1">
            <img src="images/1.jpg" alt="">
          </div>
          <div class="slide">
            <img src="images/2.jpg" alt="">
          </div>
          <div class="slide">
            <img src="images/3.jpg" alt="">
          </div>
          <div class="slide">
            <img src="images/4.jpg" alt="">
          </div>
          <div class="slide">
            <img src="images/5.jpg" alt="">
          </div>
        </div>
  
        <div class="navigation">
          <label for="r1" class="bar"></label>
          <label for="r2" class="bar"></label>
          <label for="r3" class="bar"></label>
          <label for="r4" class="bar"></label>
          <label for="r5" class="bar"></label>
        </div>
     

    </div>

    <div class ="glass-effect">
    </div>


     

    
    

    







</body>

</html>